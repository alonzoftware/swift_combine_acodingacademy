//
//  ContentView.swift
//  BatchImages
//
//  Created by Julio César Fernández Muñoz on 7/6/21.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject var fotosVM = BatchImagesVM()
    let columns:[GridItem] = .init(repeating: .init(.flexible()), count: 2)
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns) {
                ForEach(fotosVM.fotos) { foto in
                    foto.image
                        .resizable()
                        .scaledToFit()
                }
            }
        }
        .onAppear {
            fotosVM.getImages()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
