//
//  ImagesVM.swift
//  BatchImages
//
//  Created by Julio César Fernández Muñoz on 7/6/21.
//

import SwiftUI
import Combine

final class BatchImagesVM:ObservableObject {
    @Published var fotos:[Fotos] = []
        
    var subscribers = Set<AnyCancellable>()
    var imagePublishers:[AnyPublisher<Fotos, URLError>] {
        ImagesData().images.map { getImagePublisher(url: $0) }
    }
    
    func getImagePublisher(url:URL) -> AnyPublisher<Fotos, URLError> {
        URLSession.shared
            .dataTaskPublisher(for: url)
            .map(\.data)
            .compactMap { UIImage(data: $0) }
            .map { Fotos(image: Image(uiImage: $0)) }
            .eraseToAnyPublisher()
    }
    
    func getImages() {
        Publishers.MergeMany(imagePublishers)
            .collect()
            .sink { completion in
                if case .failure(let error) = completion {
                    print("Error en la descarga \(error)")
                }
            } receiveValue: { fotosRecuperadas in
                self.fotos = fotosRecuperadas
            }
            .store(in: &subscribers)
    }
}
