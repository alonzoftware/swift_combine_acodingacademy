//
//  BatchImagesApp.swift
//  BatchImages
//
//  Created by Julio César Fernández Muñoz on 7/6/21.
//

import SwiftUI

@main
struct BatchImagesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
